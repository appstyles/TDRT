# Quellenliste – Daten
- OpenStreetMap: Kartenausschnitt – CC BY-SA 2.0
- Natural Earth Data – Public Domain