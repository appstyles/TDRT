# TDRT Basis – Öffentliche Kernteile

Inhalt folgt.