# Quellenliste – Theorie
- Wikipedia: Thermodynamik – CC BY-SA 3.0
- Wikipedia: Raumzeit – CC BY-SA 3.0
- Wikibooks: Physik – Grundlagen – CC BY-SA 3.0
- Internet Archive: Principles of Thermodynamics – Public Domain