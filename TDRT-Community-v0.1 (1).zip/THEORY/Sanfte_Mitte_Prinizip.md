# Prinzip der Sanften Mitte

Inhalt folgt.