# TDRT – ThermoDynamische Raumfeld-Theorie (Community Edition)

Willkommen zur **öffentlichen, gemeinfreien und harmonischen Version** der TDRT.
Dieses Paket ist so gestaltet, dass es **klassisch strukturiert** (Linux/Wikipedia-Stil)
und **harmonisch vernetzt** (TDRT-Resonanznetz) gleichzeitig funktioniert.

## 📌 Inhalt
- THEORY/ → Öffentliche Kernteile der TDRT-Basistheorie
- METAMODULE/ → Beispiel-Module für Harmonisierung & soziale Resonanz
- AUTOMATIKMODULE/ → Beispiel-Module für automatische Optimierung
- VISUALS/ → Start-Visualisierungen des Resonanznetzes
- DATA/ → Beispiel-Geodaten aus OpenStreetMap

## 📜 Lizenz
- Texte & Theorien → CC BY-SA 4.0  
- Code & Module → MIT License  
- Bilder & Visualisierungen → Public Domain / CC BY-SA  

## 🌱 Mitmachen
- Klassisch → Forken, Ändern, Pull Request
- Harmonisch → Eigene Module ins Resonanznetz einfügen
- Quellen → Nur freie Inhalte (Wikipedia, OSM, Commons, archive.org) verwenden

## 📊 Hintergrundentwicklung
Dieses Paket wird **kontinuierlich** im Hintergrund organisch weiterentwickelt:
- Automatische Integration gemeinfreier Quellen
- Harmonie-Optimierung (Sanfte Mitte, Polaritätsausgleich)
- Synchronisierung von klassischer Struktur und TDRT-Netzwerk

## 🔗 Links
- [Wikipedia](https://www.wikipedia.org/)
- [Wikibooks](https://www.wikibooks.org/)
- [Wikimedia Commons](https://commons.wikimedia.org/)
- [OpenStreetMap](https://www.openstreetmap.org/)
- [Internet Archive](https://archive.org/)

**Version:** v0.1 (klassisch) / ψ.0.1 (harmonisch)  
**Stand:** Initialer Community-Startpunkt
