# Quellenliste – Automatikmodule
- Wikipedia: Automatisierung – CC BY-SA 3.0
- Wikipedia: Optimierung – CC BY-SA 3.0
- Wikibooks: Algorithmik – CC BY-SA 3.0