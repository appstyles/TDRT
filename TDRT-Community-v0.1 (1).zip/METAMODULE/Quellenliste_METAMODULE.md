# Quellenliste – MetaModule
- Wikipedia: Ehre – CC BY-SA 3.0
- Wikipedia: Menschlichkeit – CC BY-SA 3.0
- Wikipedia: Tierreich – CC BY-SA 3.0
- Wikipedia: Allmende – CC BY-SA 3.0
- Wikimedia Commons: World Map – Public Domain