# Quellenliste – Visuals
- Wikimedia Commons: Network Graph Example – CC BY-SA 4.0
- Wikimedia Commons: Resonance Pattern – Public Domain